# Laborator: funcții, metode și importuri pe web
# Student: Iurceac Anastasia
# Bonus: get_title() și extract_links() rescrise cu BeautifulSoup.
# Instalare: pip install beautifulsoup4

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import requests
from bs4 import BeautifulSoup


def get_title(html: str) -> str:
    """Returnează titlul paginii (șir gol dacă lipsește), folosind BeautifulSoup."""
    soup = BeautifulSoup(html, "html.parser")
    if soup.title is None or soup.title.string is None:
        return ""
    return soup.title.string.strip()


def extract_links(html: str) -> list:
    """Returnează valorile href din tag-urile <a>, fără duplicate, în ordine."""
    soup = BeautifulSoup(html, "html.parser")
    return list(dict.fromkeys(a["href"] for a in soup.find_all("a", href=True)))


# Comparație cu varianta manuală (find()/regex):
# - get_title: varianta cu find("<title>") nu găsește <TITLE> sau
#   <title lang="ro">; BeautifulSoup le tratează corect.
# - extract_links: regex-ul href="..." ratează href='...' și href fără ghilimele
#   și ar prinde și href din comentarii sau din <link>; find_all("a", href=True)
#   parsează HTML-ul real.
# - Codul este mai scurt (2-3 linii față de 6-8) și mai sigur.

if __name__ == "__main__":
    page = requests.get(BASE_URL, timeout=TIMEOUT).text
    print("Titlu:", get_title(page))
    print("Legături:", extract_links(page))

    tricky = "<HTML><TITLE lang='ro'> Salut </TITLE><a href='/x'>x</a><a href=/y>y</a></HTML>"
    print("Test dificil:", repr(get_title(tricky)), extract_links(tricky))
