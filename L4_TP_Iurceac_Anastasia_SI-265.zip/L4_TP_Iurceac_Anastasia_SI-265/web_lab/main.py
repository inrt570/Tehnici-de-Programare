# Laborator: funcții, metode și importuri pe web
# Student: Iurceac Anastasia

import argparse

# Ex. 44: importul modulului întreg. Se apelează cu prefix: webtools.fetch(...)
import webtools

# Ex. 45: importul unor nume anume. Se apelează fără prefix.
from webtools import DEFAULT_HEADERS, check_paths, get_title, security_headers, write_csv
# Dacă main.py ar avea și o funcție proprie get_title, ea ar înlocui numele
# importat: Python păstrează ultima legare a numelui, deci get_title ar însemna
# funcția din main.py, iar cea din webtools ar rămâne accesibilă doar ca
# webtools.get_title. Fără niciun avertisment, de aceea importurile cu nume
# trebuie alese cu grijă.


def main() -> None:
    """Citește URL-ul din linia de comandă și rulează toate verificările."""
    parser = argparse.ArgumentParser(description="Raport despre un site web.")
    parser.add_argument("url", help="adresa site-ului, ex.: https://cybercor.org")
    args = parser.parse_args()
    url = args.url.rstrip("/")

    print("DEFAULT_HEADERS:", DEFAULT_HEADERS)  # ex. 47

    page = webtools.fetch(url)                  # ex. 44, cu prefix
    print("Titlu (webtools.get_title):", webtools.get_title(page.text))
    print("Titlu (get_title):         ", get_title(page.text))  # ex. 45, fără prefix
    print("Antete de securitate:", security_headers(url))

    results = check_paths(url, ["/", "/robots.txt", "/sitemap.xml"])
    write_csv(results, "report.csv")            # ex. 49
    print("Salvat în report.csv:", results)
    print()

    webtools.site_report(url, "report.json")    # ex. 50


if __name__ == "__main__":
    main()
