# Laborator: funcții, metode și importuri pe web
# Student: Iurceac Anastasia

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import time

# --- Exercițiul 1: primul import ------------------------------------------
import requests
print("[1] requests versiunea:", requests.__version__)

import urllib.request
# requests este un pachet extern (scris de comunitate), care nu vine cu Python,
# de aceea trebuie descărcat cu pip install. urllib face parte din biblioteca
# standard: este instalat automat împreună cu Python, deci nu cere pip.

# --- Exercițiul 2: două stiluri de import ---------------------------------
print("\n[2] Stilul 1: import requests")
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("    cod de stare:", response.status_code)
time.sleep(1)

print("[2] Stilul 2: from requests import get")
from requests import get
response = get(BASE_URL, timeout=TIMEOUT)
print("    cod de stare:", response.status_code)
time.sleep(1)
# Avantaj "import requests": la fiecare apel se vede de unde vine funcția
#   (requests.get) și nu există riscul să se ciocnească cu alt "get".
# Avantaj "from requests import get": codul e mai scurt, fără prefix.

# --- Exercițiul 3: alias --------------------------------------------------
import requests as rq
print("\n[3] Alias rq")
response = rq.get(BASE_URL, timeout=TIMEOUT)
print("    cod de stare:", response.status_code)
time.sleep(1)
# Alias-ul ajută când numele e lung sau există o convenție larg cunoscută
#   (np pentru numpy, pd pentru pandas): oricine știe ce înseamnă.
# Îl face mai greu de citit când e inventat și criptic (rq, r, x): cititorul
#   trebuie să caute sus în fișier ce reprezintă.

# --- Exercițiul 4: doar biblioteca standard -------------------------------
print("\n[4] urllib.request.urlopen")
with urllib.request.urlopen(BASE_URL, timeout=TIMEOUT) as resp:
    print("    status:", resp.status)
    body = resp.read().decode("utf-8")  # .read() dă octeți; decode -> str
    print("    primele 200 de caractere:", body[:200])
time.sleep(1)

# --- Exercițiul 5: priviți în interiorul unui modul -----------------------
print("\n[5] dir(requests):")
print(dir(requests))
# get      -> funcție
# Session  -> clasă
# exceptions -> modul

# --- Exercițiul 6: documentația -------------------------------------------
print("\n[6] help(requests.get):")
help(requests.get)
# Parametrul care setează timpul maxim de așteptare este "timeout".
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("    cerere cu timeout:", response.status_code)
time.sleep(1)

# --- Exercițiul 7: cronometrarea unei cereri ------------------------------
print("\n[7] Cronometrare")
t0 = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
t1 = time.perf_counter()
print(f"    perf_counter:     {t1 - t0:.3f} s")
print(f"    response.elapsed: {response.elapsed.total_seconds():.3f} s")
# perf_counter măsoară tot timpul scurs în programul nostru (inclusiv crearea
# obiectului răspuns); elapsed măsoară de la trimiterea cererii până la
# primirea antetelor, așa că de obicei este puțin mai mic.

# --- Exercițiul 8: când un import eșuează ---------------------------------
print("\n[8] Import opțional")
try:
    import bs4
    print("    bs4 este instalat, versiunea", bs4.__version__)
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")

# Verificați-vă: modul vs pachet vs bibliotecă
# - modul: un singur fișier .py (ex.: time.py, webtools.py)
# - pachet: un director de module, cu __init__.py (ex.: requests, urllib)
# - bibliotecă: termen general, o colecție de cod reutilizabil, de obicei
#   distribuită ca unul sau mai multe pachete (ex.: biblioteca standard).
