# Laborator: funcții, metode și importuri pe web
# Student: Iurceac Anastasia

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import time

import requests

# --- Exercițiul 9: elementele de bază ale răspunsului ---------------------
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("[9]")
print(response.status_code)  # atribut (valoare, fără paranteze)
print(response.ok)           # atribut (în realitate o proprietate, se citește fără paranteze)
print(response.url)          # atribut
print(response.encoding)     # atribut
time.sleep(1)

# --- Exercițiul 10: tratarea erorilor cu o metodă -------------------------
print("\n[10]")
response.raise_for_status()  # metodă: nu face nimic dacă codul e 2xx
print("Pagina principală este în regulă.")
try:
    bad = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    bad.raise_for_status()   # ridică HTTPError pentru 4xx / 5xx
    print("Pagina inexistentă a răspuns cu:", bad.status_code)
except requests.HTTPError as err:
    print("Pagina căutată nu există, dar programul continuă normal.")
    print("Detalii:", err)
time.sleep(1)

# De aici înainte refolosim un singur răspuns, ca să nu încărcăm serverul.
response = requests.get(BASE_URL, timeout=TIMEOUT)
html = response.text

# --- Exercițiul 11: toate antetele ----------------------------------------
print("\n[11]")
for name, value in response.headers.items():
    print(f"{name}: {value}")

# --- Exercițiul 12: metode de dicționar -----------------------------------
print("\n[12]")
print("Server:", response.headers.get("Server", "lipsește"))
print("Content-Type:", response.headers.get("Content-Type", "lipsește"))
print("content-type:", response.headers.get("content-type", "lipsește"))
# Se observă că rezultatul este identic. response.headers nu este un dict
# obișnuit, ci un CaseInsensitiveDict: numele antetelor se caută fără să conteze
# literele mari/mici (iar în HTTP, numele antetelor chiar nu țin cont de ele).

# --- Exercițiul 13: înlănțuirea metodelor de șir --------------------------
print("\n[13]")
print("'cyber' apare de", response.text.lower().count("cyber"), "ori")
# Putem înlănțui pentru că .lower() returnează un obiect nou de tip str, iar
# orice str are metoda .count(). Rezultatul unei metode este obiectul pe care
# se apelează următoarea metodă.

# --- Exercițiul 14: găsirea titlului --------------------------------------
print("\n[14]")
start = html.find("<title>") + len("<title>")
end = html.find("</title>")
print("Titlu:", html[start:end].strip())

# --- Exercițiul 15: numărarea liniilor ------------------------------------
print("\n[15]")
lines = html.splitlines()
print("Număr de linii:", len(lines))
print("Cea mai lungă linie are", len(max(lines, key=len)), "caractere")

# --- Exercițiul 16: verificarea HTTPS -------------------------------------
print("\n[16]")
if response.url.startswith("https://"):
    print("Conexiune securizată")
else:
    print("Conexiune nesecurizată")
time.sleep(1)

# --- Exercițiul 17: urmărirea redirecționărilor ---------------------------
print("\n[17]")
redirected = requests.get("http://cybercor.org", timeout=TIMEOUT)
for hop in redirected.history:
    print(hop.status_code, hop.url)
print("URL final:", redirected.url)
time.sleep(1)

# --- Exercițiul 18: HEAD versus GET ---------------------------------------
print("\n[18]")
head_resp = requests.head(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
get_resp = requests.get(BASE_URL, timeout=TIMEOUT)
print("HEAD:", len(head_resp.content), "octeți")
print("GET: ", len(get_resp.content), "octeți")
# HEAD cere doar antetele: serverul nu trimite corpul, deci .content este gol
# (0 octeți). GET cere și corpul, adică tot codul HTML al paginii. HEAD e util
# când vrem doar să verificăm că o pagină există, fără să descărcăm nimic.

# --- Exercițiul 19: cookie-uri --------------------------------------------
print("\n[19]")
if len(get_resp.cookies) == 0:
    print("Niciun cookie setat")
else:
    for cookie in get_resp.cookies:
        print(cookie.name, cookie.secure)
time.sleep(1)

# --- Exercițiul 20: sesiuni (către httpbin, nu către cybercor) ------------
print("\n[20]")
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-IurceacAnastasia"})
echo = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
sent = echo.json()["headers"].get("User-Agent")
print("User-Agent primit de server:", sent)
print("Antetul a fost trimis:", sent == "WebLab-IurceacAnastasia")

# Verificați-vă: response.text este un atribut (o valoare deja calculată), deci
# se citește fără paranteze. response.json() este o metodă: face o acțiune
# (parsează textul ca JSON) și poate primi argumente, deci se apelează cu ().
