# Laborator: funcții, metode și importuri pe web
# Student: Iurceac Anastasia

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import time

import requests

SECURITY_HEADER_NAMES = (
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
)


# Ex. 21 + 23 (parametru implicit): descarcă o pagină.
def fetch(url: str, timeout: int = TIMEOUT) -> requests.Response:
    """Descarcă url și returnează obiectul răspuns (timeout implicit: TIMEOUT)."""
    return requests.get(url, timeout=timeout)


# Ex. 22: returnează o singură valoare.
def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


# Ex. 24 + 25: o singură sarcină, fără rețea; cu docstring.
def get_title(html: str) -> str:
    """Returnează textul dintre <title> și </title>, fără spații la capete.

    Primește un șir HTML (nu face nicio cerere de rețea). Dacă pagina nu are
    titlu, returnează un șir gol.
    """
    start = html.find("<title>")
    end = html.find("</title>")
    if start == -1 or end == -1:
        return ""
    return html[start + len("<title>"):end].strip()


# Ex. 27: funcție care nu se oprește cu eroare.
def page_exists(url: str) -> bool:
    """Returnează True dacă url răspunde cu un cod de succes, altfel False."""
    try:
        return fetch(url).ok
    except requests.RequestException:
        return False


# Ex. 28: returnează un dicționar.
def check_paths(base: str, paths: list) -> dict:
    """Returnează {cale: cod_de_stare} pentru fiecare cale din lista paths.

    Face o pauză de o secundă între cereri.
    """
    results = {}
    for index, path in enumerate(paths):
        if index > 0:
            time.sleep(1)
        results[path] = get_status(base + path)
    return results


# Ex. 29: argumente cu nume și valoare implicită.
def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea antetului name de la url, sau default dacă lipsește."""
    return fetch(url).headers.get(name, default)


# Ex. 30
def security_headers(url: str) -> dict:
    """Returnează {antet: True/False} pentru cele cinci antete de securitate."""
    headers = fetch(url).headers
    return {name: name in headers for name in SECURITY_HEADER_NAMES}


# Ex. 31: o funcție care lucrează cu rezultatul alteia.
def score_headers(results: dict) -> str:
    """Primește rezultatul lui security_headers și returnează scorul, ex. '3/5'."""
    present = sum(1 for value in results.values() if value)
    return f"{present}/{len(results)}"


# Ex. 32: două funcții, o sarcină.
def fetch_robots(base: str):
    """Returnează textul fișierului /robots.txt, sau None dacă lipsește."""
    try:
        response = fetch(base + "/robots.txt")
    except requests.RequestException:
        return None
    if response.status_code != 200:
        return None
    return response.text


def disallowed_paths(robots_text) -> list:
    """Returnează lista valorilor 'Disallow:' din robots_text (goală pentru None)."""
    if not robots_text:
        return []
    found = []
    for line in robots_text.splitlines():
        name, _, value = line.partition(":")
        if name.strip().lower() == "disallow" and value.strip():
            found.append(value.strip())
    return found


# Ex. 33: oricâte argumente poziționale.
def response_times(*urls: str) -> dict:
    """Returnează {url: secunde} cu timpul de răspuns pentru fiecare url."""
    times = {}
    for index, url in enumerate(urls):
        if index > 0:
            time.sleep(1)
        started = time.perf_counter()
        fetch(url)
        times[url] = round(time.perf_counter() - started, 3)
    return times


# Ex. 34: oricâte argumente cu nume.
def log(message: str, **details) -> None:
    """Afișează mesajul urmat de fiecare detaliu, separate prin ' | '."""
    parts = [message]
    for key, value in details.items():
        parts.append(f"{key}={value}")
    print(" | ".join(parts))


def demo() -> None:
    """Apelează cel puțin o dată fiecare funcție din acest fișier."""
    print("[21] fetch:", fetch(BASE_URL).status_code)
    time.sleep(1)

    print("[22] get_status:")
    for path in ("/", "/robots.txt", "/sitemap.xml"):
        print("    ", path, "->", get_status(BASE_URL + path))
        time.sleep(1)

    print("[23] timeout implicit:", fetch(BASE_URL).status_code)
    time.sleep(1)
    print("[23] timeout=3:", fetch(BASE_URL, timeout=3).status_code)
    time.sleep(1)

    html = fetch(BASE_URL).text
    print("[24] get_title:", get_title(html))
    time.sleep(1)

    print("[25] docstring:")
    help(get_title)

    print("[26] get_status(123):")
    try:
        print(get_status(123))
    except Exception as err:
        print("    ", type(err).__name__, "->", err)
    # Adnotările de tip NU ne opresc: Python nu le verifică la rulare, sunt doar
    # documentație pentru oameni și pentru unelte (mypy, editorul). Apelul a
    # pornit normal; eroarea vine din requests, care nu acceptă un număr ca URL.

    print("[27] page_exists:", page_exists(BASE_URL))
    print("[27] page_exists(.invalid):", page_exists("https://this-domain-does-not-exist.invalid"))
    time.sleep(1)

    print("[28] check_paths:", check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))
    time.sleep(1)

    print("[29] Server:", get_header(BASE_URL, name="Server"))
    time.sleep(1)

    results = security_headers(BASE_URL)
    print("[30] security_headers:", results)
    print("[31] scor:", score_headers(results))
    time.sleep(1)

    robots = fetch_robots(BASE_URL)
    print("[32] disallowed_paths:", disallowed_paths(robots))
    print("[32] disallowed_paths(None):", disallowed_paths(None))
    time.sleep(1)

    print("[33] response_times:", response_times(BASE_URL, BASE_URL + "/robots.txt"))

    log("verificat", url=BASE_URL, status=200)  # ex. 34


# Verificați-vă: print() doar AFIȘEAZĂ o valoare pe ecran; după aceea valoarea
# se pierde și codul care a apelat funcția nu o poate folosi. return o trimite
# înapoi apelantului, care o poate stoca, compara sau transmite altei funcții
# (ex.: score_headers(security_headers(url))). O funcție fără return dă None.

if __name__ == "__main__":
    demo()
