# Laborator: funcții, metode și importuri pe web
# Student: Iurceac Anastasia

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import hashlib
import json
import re
import socket
import ssl
import time
from datetime import datetime, timezone
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import requests


# Ex. 35
def show_url_parts(url: str) -> None:
    """Afișează componentele unui URL, cu urllib.parse.urlparse."""
    parts = urlparse(url)
    print("scheme  :", parts.scheme)
    print("netloc  :", parts.netloc)
    print("path    :", parts.path)
    print("query   :", parts.query)
    print("fragment:", parts.fragment)


# Ex. 36
def show_joined_urls(base: str, links: list) -> None:
    """Transformă legături relative în URL-uri complete, cu urljoin."""
    for link in links:
        print(f"{link:15} -> {urljoin(base, link)}")


# Ex. 37
def extract_links(html: str) -> list:
    """Returnează legăturile href din html, fără duplicate, în ordinea apariției."""
    found = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(found))


# Ex. 38
def split_links(links: list, domain: str) -> tuple:
    """Împarte legăturile în (interne, externe) față de domeniul domain.

    Legăturile relative sunt făcute complete cu urljoin, apoi se compară
    urlparse(...).netloc cu domain. Schemele care nu sunt web (mailto:, tel:,
    javascript:) sunt ignorate.
    """
    base = "https://" + domain
    internal = []
    external = []
    for link in links:
        full = urljoin(base, link)
        parsed = urlparse(full)
        if parsed.scheme not in ("http", "https"):
            continue
        if parsed.netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external


# Ex. 39
class ImageFinder(HTMLParser):
    """Parser care colectează atributul src al fiecărui tag <img>."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        """Apelată automat de HTMLParser pentru fiecare tag de deschidere."""
        if tag != "img":  # HTMLParser scrie deja tag-ul cu litere mici
            return
        src = dict(attrs).get("src")
        if src:
            self.images.append(src)


test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""


def test_image_finder() -> None:
    """Testează ImageFinder mai întâi pe HTML cunoscut, apoi pe site-ul real."""
    finder = ImageFinder()
    finder.feed(test_html)
    print(finder.images)

    assert finder.images == [
        "/logo.png",                            # imagine obișnuită
        "poza.jpg",                             # tag scris cu majuscule
        "https://cdn.example.com/banner.webp",  # tag care se închide singur
    ], "Parserul nu a găsit exact imaginile așteptate"
    print("Testul a trecut!")

    response = requests.get(BASE_URL, timeout=TIMEOUT)
    finder = ImageFinder()
    finder.feed(response.text)
    print(len(finder.images), "imagini găsite")
    for src in finder.images:
        print(src)
    print("Număr de '<img' în sursă:", response.text.lower().count("<img"))
    # handle_starttag nu este apelată de noi: o apelează HTMLParser din interiorul
    # lui feed(), de fiecare dată când ajunge la un tag de deschidere.


# Ex. 40
def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 (în hexazecimal) a conținutului de la url."""
    response = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()


# Ex. 41
def save_headers_json(url: str, filename: str = "headers.json") -> None:
    """Salvează antetele de la url în fișier JSON, apoi le reîncarcă și afișează unul."""
    response = requests.get(url, timeout=TIMEOUT)
    with open(filename, "w", encoding="utf-8") as file:
        json.dump(dict(response.headers), file, indent=2)

    with open(filename, encoding="utf-8") as file:
        loaded = json.load(file)
    print("Content-Type din fișier:", loaded.get("Content-Type", "lipsește"))


# Ex. 42
def resolve(hostname: str) -> str:
    """Returnează adresa IPv4 a lui hostname (interogare DNS)."""
    return socket.gethostbyname(hostname)


# Ex. 43
def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului TLS al lui hostname."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as tls:
            cert = tls.getpeercert()
    expires_at = ssl.cert_time_to_seconds(cert["notAfter"])
    now = datetime.now(timezone.utc).timestamp()
    return int((expires_at - now) // 86400)


def demo() -> None:
    """Apelează toate funcțiile din acest fișier, cu pauze între cereri."""
    print("[35]")
    show_url_parts("https://cybercor.org/path?x=1#top")

    print("\n[36]")
    show_joined_urls(BASE_URL, ["/about", "contact.html", "../index.html"])

    print("\n[37-38]")
    html = requests.get(BASE_URL, timeout=TIMEOUT).text
    links = extract_links(html)
    print("Legături unice:", links)
    internal, external = split_links(links, urlparse(BASE_URL).netloc)
    print(len(internal), "interne,", len(external), "externe")
    time.sleep(1)

    print("\n[39]")
    test_image_finder()
    time.sleep(1)

    print("\n[40]")
    first = page_fingerprint(BASE_URL)
    time.sleep(1)
    second = page_fingerprint(BASE_URL)
    print(first)
    print(second)
    print("Amprente", "identice" if first == second else "diferite")
    # Ar fi diferite dacă pagina conține ceva care se schimbă la fiecare cerere
    # (data/ora, un token CSRF, reclame, un contor de vizite) sau dacă site-ul a
    # fost modificat între cele două cereri.
    time.sleep(1)

    print("\n[41]")
    save_headers_json(BASE_URL)

    print("\n[42]")
    print("IP cybercor.org:", resolve("cybercor.org"))

    print("\n[43]")
    print("Certificat:", cert_days_left("cybercor.org"), "zile rămase")


# Verificați-vă: handle_starttag() este apelată de HTMLParser însuși, din
# interiorul metodei feed(). Noi doar o suprascriem; parserul decide când o
# apelează (la fiecare tag de deschidere). Acesta este un "callback".

if __name__ == "__main__":
    demo()
