# Laborator: funcții, metode și importuri pe web
# Student: Iurceac Anastasia
"""Modul cu funcții reutilizabile pentru analiza unui site web."""

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import csv
import json
import socket
import ssl
import re
import time
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse

import requests

# Ex. 47: constantă de modul, folosită în fetch().
DEFAULT_HEADERS = {"User-Agent": "WebLab-IurceacAnastasia"}

SECURITY_HEADER_NAMES = (
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
)


# --- Ex. 44: funcțiile mutate din partea 3 --------------------------------
def fetch(url: str, timeout: int = TIMEOUT) -> requests.Response:
    """Descarcă url (cu DEFAULT_HEADERS) și returnează obiectul răspuns."""
    return requests.get(url, timeout=timeout, headers=DEFAULT_HEADERS)


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


def get_title(html: str) -> str:
    """Returnează textul dintre <title> și </title>, fără spații la capete.

    Dacă pagina nu are titlu, returnează un șir gol.
    """
    start = html.find("<title>")
    end = html.find("</title>")
    if start == -1 or end == -1:
        return ""
    return html[start + len("<title>"):end].strip()


def security_headers(url: str) -> dict:
    """Returnează {antet: True/False} pentru cele cinci antete de securitate."""
    headers = fetch(url).headers
    return {name: name in headers for name in SECURITY_HEADER_NAMES}


# --- Restul funcțiilor din părțile 3 și 4, necesare raportului ------------
def score_headers(results: dict) -> str:
    """Primește rezultatul lui security_headers și returnează scorul, ex. '3/5'."""
    present = sum(1 for value in results.values() if value)
    return f"{present}/{len(results)}"


def check_paths(base: str, paths: list) -> dict:
    """Returnează {cale: cod_de_stare} (None dacă cererea eșuează), cu pauză între cereri."""
    results = {}
    for index, path in enumerate(paths):
        if index > 0:
            time.sleep(1)
        try:
            results[path] = get_status(base + path)
        except requests.RequestException:
            results[path] = None
    return results


def fetch_robots(base: str):
    """Returnează textul fișierului /robots.txt, sau None dacă lipsește."""
    try:
        response = fetch(base + "/robots.txt")
    except requests.RequestException:
        return None
    if response.status_code != 200:
        return None
    return response.text


def disallowed_paths(robots_text) -> list:
    """Returnează lista valorilor 'Disallow:' din robots_text (goală pentru None)."""
    if not robots_text:
        return []
    found = []
    for line in robots_text.splitlines():
        name, _, value = line.partition(":")
        if name.strip().lower() == "disallow" and value.strip():
            found.append(value.strip())
    return found


def extract_links(html: str) -> list:
    """Returnează legăturile href din html, fără duplicate, în ordinea apariției."""
    return list(dict.fromkeys(re.findall(r'href="([^"]+)"', html)))


def split_links(links: list, domain: str) -> tuple:
    """Împarte legăturile în (interne, externe) față de domeniul domain."""
    base = "https://" + domain
    internal = []
    external = []
    for link in links:
        full = urljoin(base, link)
        parsed = urlparse(full)
        if parsed.scheme not in ("http", "https"):
            continue
        if parsed.netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external


def resolve(hostname: str) -> str:
    """Returnează adresa IPv4 a lui hostname (interogare DNS)."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului TLS al lui hostname."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as tls:
            cert = tls.getpeercert()
    expires_at = ssl.cert_time_to_seconds(cert["notAfter"])
    now = datetime.now(timezone.utc).timestamp()
    return int((expires_at - now) // 86400)


def redirect_chain(url: str) -> list:
    """Returnează redirecționările lui url ca texte de forma '301 -> https://...'."""
    response = fetch(url)
    hops = response.history + [response]
    return [f"{hops[i].status_code} -> {hops[i + 1].url}" for i in range(len(hops) - 1)]


# --- Ex. 49: raport CSV ----------------------------------------------------
def write_csv(results: dict, filename: str = "report.csv") -> None:
    """Salvează {cale: status} în CSV, cu coloanele path, status și checked_at."""
    with open(filename, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["path", "status", "checked_at"])
        for path, status in results.items():
            writer.writerow([path, status, datetime.now().isoformat()])


# --- Ex. 50: proiectul final ----------------------------------------------
def site_report(url: str, out_file: str = "report.json") -> dict:
    """Colectează informații despre site, le afișează și le salvează în out_file (JSON).

    Fiecare verificare este protejată separat: dacă una eșuează, raportul
    continuă cu valoarea None pentru acea verificare. Între cererile HTTP se
    face o pauză de o secundă.
    """
    url = url.rstrip("/")
    page = fetch(url)
    host = urlparse(page.url).hostname
    title = get_title(page.text)
    internal, external = split_links(extract_links(page.text), host)

    try:
        ip = resolve(host)
    except OSError:
        ip = None

    time.sleep(1)
    try:
        redirects = redirect_chain("http://" + host + "/")
    except requests.RequestException:
        redirects = None

    time.sleep(1)
    try:
        score = score_headers(security_headers(url))
    except requests.RequestException:
        score = None

    try:
        days = cert_days_left(host)
    except OSError:
        days = None

    time.sleep(1)
    disallowed = disallowed_paths(fetch_robots(url))

    report = {
        "url": url,
        "status_code": page.status_code,
        "final_url": page.url,
        "title": title,
        "ip": ip,
        "redirects": redirects,
        "security_score": score,
        "cert_days_left": days,
        "internal_links": len(internal),
        "external_links": len(external),
        "disallowed_paths": disallowed,
        "generated_at": datetime.now().isoformat(),
    }

    redirects_text = "indisponibil" if redirects is None else (", ".join(redirects) or "fără redirecționări")
    cert_text = "indisponibil" if days is None else f"{days} de zile rămase"
    print(f"=== Raport site: {url} ===")
    print(f"Cod de stare:      {page.status_code}")
    print(f"URL final:         {page.url}")
    print(f"Titlu:             {title}")
    print(f"Adresă IP:         {ip or 'indisponibilă'}")
    print(f"Redirecționări:    {redirects_text}")
    print(f"Scor securitate:   {score or 'indisponibil'}")
    print(f"Certificat:        {cert_text}")
    print(f"Legături:          {len(internal)} interne, {len(external)} externe")
    print(f"Căi interzise:     {', '.join(disallowed) if disallowed else 'niciuna'}")

    with open(out_file, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print(f"Salvat în {out_file}")
    return report


# Ex. 46: blocul main. Când rulăm "python webtools.py", Python setează
# __name__ = "__main__" și autotestul rulează. Când main.py face
# "import webtools", __name__ devine "webtools", deci condiția e falsă și
# autotestul este sărit (altfel s-ar face o cerere de rețea la fiecare import).
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
